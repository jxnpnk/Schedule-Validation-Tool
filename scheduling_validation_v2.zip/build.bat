@echo off
echo ============================================
echo  SF vs Deputy Validation Tool - Builder
echo ============================================
echo.

REM Check Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.10+ from https://python.org
    pause
    exit /b 1
)

echo [1/3] Installing dependencies...
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)

echo [2/3] Building executable...
python -m PyInstaller SFDeputyValidation.spec --distpath dist --workpath build_work --noconfirm
if errorlevel 1 (
    echo ERROR: Build failed.
    pause
    exit /b 1
)

echo.
echo [3/3] Done!
echo.
echo The application is in:  dist\SF Deputy Validation\
echo Double-click "SF Deputy Validation.exe" to run it.
echo.
echo You can zip the "dist\SF Deputy Validation" folder and share it with users.
echo Users do NOT need Python installed.
echo.
pause
