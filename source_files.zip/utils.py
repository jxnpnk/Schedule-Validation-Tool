import re
import pandas as pd
import datetime
from rapidfuzz import fuzz

NAME_MATCH_THRESHOLD = 85

# Strips (NA), (V), (F), (PS), (T1), (T2), (T3) from anywhere in the name
_NOISE_PAREN_RE = re.compile(r"\s*\((NA|V|F|PS|T1|T2|T3)\)\s*", re.IGNORECASE)

_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}")


def clean_consultant_name(value):
    """Strip noise tokens, underscores, and normalise whitespace from a consultant name."""
    if pd.isna(value):
        return ""
    s = str(value).strip()
    s = s.replace("_", " ")
    # Strip leading 'z' before a letter (e.g. zJohn -> John)
    s = re.sub(r"^z([A-Za-z])", r"\1", s, flags=re.IGNORECASE)
    s = _NOISE_PAREN_RE.sub(" ", s)
    s = s.strip()
    return s


def compare_names(name1, name2):
    n1 = clean_consultant_name(name1).lower()
    n2 = clean_consultant_name(name2).lower()
    if not n1 or not n2:
        return False
    if n1 == n2:
        return True
    # Also try first-name-only match for partial names
    parts1 = n1.split()
    parts2 = n2.split()
    if parts1 and parts2 and parts1[0] == parts2[0]:
        return True
    return fuzz.ratio(n1, n2) >= NAME_MATCH_THRESHOLD


def _parse_date_smart(value_str):
    s = str(value_str).strip()
    if _ISO_DATE_RE.match(s):
        return pd.to_datetime(s, dayfirst=False).date()
    return pd.to_datetime(s, dayfirst=True).date()


def parse_deputy_date(value):
    """Parse a Deputy date from various formats."""
    if pd.isna(value):
        return None
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.date() if isinstance(value, datetime.datetime) else value
    if isinstance(value, pd.Timestamp):
        return value.date()
    # Excel serial number
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if 10000 < value < 100000:
            try:
                return (pd.Timestamp("1899-12-30") + pd.Timedelta(days=int(value))).date()
            except Exception:
                pass
    try:
        return _parse_date_smart(value)
    except Exception:
        return None


def parse_deputy_time(value):
    """Parse a Deputy time from various formats."""
    if pd.isna(value):
        return None
    if isinstance(value, datetime.time):
        return value
    if isinstance(value, (datetime.datetime, pd.Timestamp)):
        return value.time()
    if isinstance(value, float) and 0.0 <= value < 1.0:
        # Day fraction
        total_seconds = int(round(value * 86400))
        h, rem = divmod(total_seconds, 3600)
        m, s = divmod(rem, 60)
        return datetime.time(h, m, s)
    try:
        return pd.to_datetime(str(value)).time()
    except Exception:
        return None


def duration_hours(start_time, end_time):
    """Return duration in hours between two datetime.time objects, or None."""
    if start_time is None or end_time is None:
        return None
    try:
        dt_start = datetime.datetime.combine(datetime.date.today(), start_time)
        dt_end = datetime.datetime.combine(datetime.date.today(), end_time)
        diff = (dt_end - dt_start).total_seconds() / 3600
        if diff < 0:
            diff += 24
        return diff
    except Exception:
        return None
