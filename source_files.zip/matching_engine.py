"""
Core validation engine: matches SF opportunities against Deputy diary rows.
"""
import re
import datetime
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

import pandas as pd

from utils import (
    clean_consultant_name,
    compare_names,
    parse_deputy_date,
    parse_deputy_time,
    duration_hours,
)
from diary_parser import DiaryRow, parse_diary_note
from service_lookup import ServiceLookup, split_deputy_area, FRA_TIER_HIERARCHY

HOURS_PER_DAY = 8.0  # basis for fractional day duration check
FRACTIONAL_DAY_TOLERANCE_HOURS = 1.0  # ± 1 hour tolerance for duration check


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _find_column(df, candidates):
    """Case-insensitive flexible column finder."""
    cols_lower = {c.strip().lower(): c for c in df.columns}
    for cand in candidates:
        hit = cols_lower.get(cand.strip().lower())
        if hit:
            return hit
    return None


# ---------------------------------------------------------------------------
# Error container
# ---------------------------------------------------------------------------

@dataclass
class RowError:
    row_index: int
    error_message: str
    raw_data: str = ""


# ---------------------------------------------------------------------------
# Result containers
# ---------------------------------------------------------------------------

@dataclass
class OpportunityResult:
    opportunity_number: str
    account_name: str
    flags: List[str] = field(default_factory=list)
    flag_details: Dict[str, str] = field(default_factory=dict)
    matched_diary_shift_ids: List[str] = field(default_factory=list)
    sf_visits: int = 0
    visit_dates: List[str] = field(default_factory=list)
    diary_dates: List[str] = field(default_factory=list)
    consultants: List[str] = field(default_factory=list)
    visit_entries_match: str = "N/A"

    def add_flag(self, flag_code, detail=""):
        if flag_code not in self.flags:
            self.flags.append(flag_code)
        if detail:
            existing = self.flag_details.get(flag_code, "")
            if existing and detail not in existing:
                self.flag_details[flag_code] = existing + "; " + detail
            else:
                self.flag_details[flag_code] = detail


# ---------------------------------------------------------------------------
# Load diary rows
# ---------------------------------------------------------------------------

def load_diary_rows(diary_df):
    """
    Parse diary DataFrame into DiaryRow objects.
    Returns (rows: List[DiaryRow], errors: List[RowError])
    """
    rows = []
    errors = []

    col_shift_id   = _find_column(diary_df, ["Shift ID", "ShiftID", "ID"])
    col_area       = _find_column(diary_df, ["Area", "Department", "Work Area"])
    col_employee   = _find_column(diary_df, ["Employee", "Employee Name", "Name", "Staff Name"])
    col_date       = _find_column(diary_df, ["Date", "Start Date", "Shift Date"])
    col_start_time = _find_column(diary_df, ["Start Time", "StartTime", "Time Start"])
    col_end_time   = _find_column(diary_df, ["End Time", "EndTime", "Time End", "Finish Time"])
    col_note       = _find_column(diary_df, ["New Note", "Note", "Notes", "Comment", "Comments"])

    for idx, row in diary_df.iterrows():
        try:
            shift_id   = str(row[col_shift_id]).strip()   if col_shift_id   else str(idx)
            area       = str(row[col_area]).strip()        if col_area       else ""
            employee   = str(row[col_employee]).strip()    if col_employee   else ""
            start_date = parse_deputy_date(row[col_date]) if col_date       else None
            start_time = parse_deputy_time(row[col_start_time]) if col_start_time else None
            end_time   = parse_deputy_time(row[col_end_time])   if col_end_time   else None
            note_raw   = str(row[col_note]).strip()        if col_note       else ""

            parsed = parse_diary_note(note_raw)

            dr = DiaryRow(
                shift_id=shift_id,
                area=area,
                employee_raw=employee,
                start_date=start_date,
                start_time=start_time,
                end_time=end_time,
                note_raw=note_raw,
                op_candidates=parsed["op_candidates"],
                day_number=parsed["day_number"],
                total_days=parsed["total_days"],
                postcode=parsed["postcode"],
                secondary_consultant=parsed["secondary_consultant"],
                is_multi_op=parsed["is_multi_op"],
            )
            rows.append(dr)
        except Exception as e:
            errors.append(RowError(
                row_index=idx,
                error_message=str(e),
                raw_data=str(row.to_dict()),
            ))

    return rows, errors


# ---------------------------------------------------------------------------
# Core per-opportunity processing
# ---------------------------------------------------------------------------

def _process_opportunity(op_number, group, op_diary_rows, service_lookup, col_map):
    """
    Validate one SF opportunity against its matched diary rows.
    Returns OpportunityResult.
    """
    col_account     = col_map["account"]
    col_service     = col_map["service"]
    col_consultant  = col_map["consultant"]
    col_date        = col_map["date"]
    col_postcode    = col_map.get("postcode")
    col_site_time   = col_map.get("site_time")

    account_name = str(group.iloc[0][col_account]).strip() if col_account else ""

    result = OpportunityResult(
        opportunity_number=op_number,
        account_name=account_name,
        sf_visits=len(group),
    )

    # Collect visit dates and consultants for reporting
    for _, sf_row in group.iterrows():
        d = parse_deputy_date(sf_row[col_date]) if col_date else None
        if d:
            result.visit_dates.append(str(d))
        c = clean_consultant_name(sf_row[col_consultant]) if col_consultant else ""
        if c and c not in result.consultants:
            result.consultants.append(c)

    # ------------------------------------------------------------------
    # 1. Check diary rows exist for this OP
    # ------------------------------------------------------------------
    if not op_diary_rows:
        result.add_flag("MISSING_FROM_DIARY", f"OP {op_number} not found in any diary note")
        return result

    result.matched_diary_shift_ids = [dr.shift_id for dr in op_diary_rows]
    result.diary_dates = sorted(set(
        str(dr.start_date) for dr in op_diary_rows if dr.start_date is not None
    ))

    # ------------------------------------------------------------------
    # 2. Service check — per SF row, check diary area matches
    # ------------------------------------------------------------------
    # Collect all SF services (with FRA tier reduction)
    sf_services_raw = [
        str(sf_row[col_service]).strip()
        for _, sf_row in group.iterrows()
        if col_service and not pd.isna(sf_row[col_service])
    ]
    sf_services = service_lookup.reduce_fra_tiers(sf_services_raw)

    # Collect all Deputy area tokens from matched diary rows
    diary_area_tokens = []
    unmapped_areas = []
    for dr in op_diary_rows:
        for token in split_deputy_area(dr.area):
            if not token:
                continue
            if service_lookup.is_admin_area(token):
                continue
            canonical = service_lookup.normalise_token(token)
            if canonical is None:
                unmapped_areas.append(token)
            else:
                diary_area_tokens.append(canonical)

    # Match each SF service against diary tokens
    for sf_service in sf_services:
        if pd.isna(sf_service) or not sf_service:
            continue
        found = False
        for diary_canonical in diary_area_tokens:
            if diary_canonical.lower() == sf_service.lower():
                found = True
                break
            if service_lookup.services_are_equivalent(sf_service, diary_canonical):
                found = True
                break
        if not found:
            result.add_flag(
                "SERVICE_MISMATCH",
                f"SF service '{sf_service}' not found in diary areas {diary_area_tokens}",
            )

    # ------------------------------------------------------------------
    # 3. Date check — each SF date should have a matching diary row
    # ------------------------------------------------------------------
    for _, sf_row in group.iterrows():
        sf_date = parse_deputy_date(sf_row[col_date]) if col_date else None
        if sf_date is None:
            continue
        date_match = any(dr.start_date == sf_date for dr in op_diary_rows)
        if not date_match:
            result.add_flag(
                "DATE_MISMATCH",
                f"SF date {sf_date} not found in diary for OP {op_number}",
            )

    # ------------------------------------------------------------------
    # 4. Postcode check
    # ------------------------------------------------------------------
    if col_postcode:
        sf_postcodes = set()
        for _, sf_row in group.iterrows():
            pc = sf_row.get(col_postcode, None)
            if not pd.isna(pc) and str(pc).strip():
                sf_postcodes.add(str(pc).strip().upper().replace(" ", ""))

        diary_postcodes = set()
        for dr in op_diary_rows:
            if dr.postcode:
                diary_postcodes.add(dr.postcode.upper().replace(" ", ""))

        if sf_postcodes and diary_postcodes:
            if not sf_postcodes.intersection(diary_postcodes):
                result.add_flag(
                    "POSTCODE_MISMATCH",
                    f"SF postcodes {sf_postcodes} vs diary {diary_postcodes}",
                )

    # ------------------------------------------------------------------
    # 5. Consultant check — per SF row, find matching diary row by date
    #    Secondary consultants (appearing via WITH in diary) are handled
    #    separately in step 7, so skip them here.
    # ------------------------------------------------------------------
    for _, sf_row in group.iterrows():
        sf_date = parse_deputy_date(sf_row[col_date]) if col_date else None
        sf_consultant = clean_consultant_name(sf_row[col_consultant]) if col_consultant else ""
        if not sf_consultant or sf_date is None:
            continue

        # Find diary rows for this date
        diary_on_date = [dr for dr in op_diary_rows if dr.start_date == sf_date]
        if not diary_on_date:
            continue  # already flagged in date check

        # Multiple diary rows on same date — only flag if SF also has just 1 consultant
        # on this date (multi-consultant dates are handled by step 7)
        sf_consultants_on_date = [
            clean_consultant_name(r2[col_consultant])
            for _, r2 in group.iterrows()
            if parse_deputy_date(r2[col_date]) == sf_date
            and not pd.isna(r2[col_consultant])
        ]
        if len(diary_on_date) > 1 and len(sf_consultants_on_date) < 2:
            result.add_flag(
                "MULTIPLE_DIARY_ROWS_SAME_DATE",
                f"Date {sf_date}: {len(diary_on_date)} diary rows found but only 1 SF consultant",
            )
            continue
        if len(sf_consultants_on_date) >= 2:
            continue  # handled in step 7

        diary_row = diary_on_date[0]
        diary_consultant = clean_consultant_name(diary_row.employee_raw)

        # Check if this SF consultant matches the primary diary consultant
        if compare_names(sf_consultant, diary_consultant):
            continue  # primary match — fine

        # If there are 2+ SF consultants on this date, the WITH logic in step 7
        # handles the cross-check — don't double-flag here
        sf_consultants_on_date = [
            clean_consultant_name(r[col_consultant])
            for _, r in group.iterrows()
            if parse_deputy_date(r[col_date]) == sf_date
            and not pd.isna(r[col_consultant])
        ]
        if len(sf_consultants_on_date) >= 2:
            continue  # multi-consultant date — handled by step 7

        result.add_flag(
            "CONSULTANT_MISMATCH",
            f"SF: '{sf_consultant}' vs diary: '{diary_consultant}' on {sf_date}",
        )

    # ------------------------------------------------------------------
    # 6. Site Time check (replaces VISIT_COUNT_MISMATCH)
    #    Compares SF Site Time column vs "Day X of Y" → Y in diary
    # ------------------------------------------------------------------
    _check_site_time(result, group, op_diary_rows, col_site_time, col_date)

    # ------------------------------------------------------------------
    # 7. Secondary consultant cross-check (replaces AMBIGUOUS_MATCH / SECONDARY_CONSULTANT)
    #    When diary note says "WITH <name>", verify that person appears in SF for same OP/date
    # ------------------------------------------------------------------
    _check_secondary_consultants(result, group, op_diary_rows, col_consultant, col_date)

    return result


# ---------------------------------------------------------------------------
# Site Time check
# ---------------------------------------------------------------------------

def _check_site_time(result, sf_group, op_diary_rows, col_site_time, col_date):
    """
    Compare SF Site Time vs diary "Day X of Y" total (Y value).
    For fractional Site Times (not x.0), also checks the short diary row's duration.
    """
    import math

    # Get SF Site Time — take first non-blank value (consistent per OP)
    sf_site_time = None
    if col_site_time:
        for _, sf_row in sf_group.iterrows():
            val = sf_row.get(col_site_time)
            if val is None:
                continue
            try:
                if pd.isna(val):
                    continue
            except (TypeError, ValueError):
                pass
            if isinstance(val, (int, float)) and not isinstance(val, bool):
                sf_site_time = float(val)
                break
            val_str = str(val).strip()
            if val_str and val_str.lower() not in ("", "nan", "none", "n/a", "<na>"):
                try:
                    sf_site_time = float(val_str)
                    break
                except (ValueError, TypeError):
                    pass

    # Find the "total_days" from diary rows (Y in Day X of Y)
    diary_total_days = None
    diary_has_notation = False
    for dr in op_diary_rows:
        if dr.total_days is not None:
            diary_has_notation = True
            if diary_total_days is None or dr.total_days > diary_total_days:
                diary_total_days = dr.total_days

    # Neither side has info — nothing to check
    if sf_site_time is None and not diary_has_notation:
        return

    # SF blank, diary has notation
    if sf_site_time is None and diary_has_notation:
        result.add_flag(
            "SITE_TIME_NEEDS_CONFIRMATION",
            f"Diary shows {diary_total_days} days total but SF Site Time is blank",
        )
        return

    # SF present, diary has no notation
    if sf_site_time is not None and not diary_has_notation:
        if sf_site_time == 1.0:
            return  # single day, no notation needed — fine
        # All other values (including fractional): flag for confirmation
        result.add_flag(
            "SITE_TIME_NEEDS_CONFIRMATION",
            f"SF Site Time={sf_site_time} — please confirm, not shown in diary",
        )
        return

    # Both present: diary Y should equal ceil(SF Site Time)
    # e.g. 1.5 → 2 diary entries; 2.0 → 2 diary entries; 0.75 → 1 diary entry
    expected_diary_total = math.ceil(sf_site_time)
    if expected_diary_total != int(diary_total_days):
        result.add_flag(
            "SITE_TIME_MISMATCH",
            f"SF Site Time={sf_site_time} (expects {expected_diary_total} diary entries) "
            f"but diary shows {int(diary_total_days)} total",
        )

    # Fractional duration check — only when site_time is NOT a whole number (x.0)
    fractional_part = sf_site_time % 1
    if fractional_part != 0.0:
        expected_hours = fractional_part * HOURS_PER_DAY
        # The fractional day is the last diary entry (day_number == ceil(sf_site_time))
        last_day_num = float(math.ceil(sf_site_time))
        for dr in op_diary_rows:
            if dr.day_number != last_day_num:
                continue
            actual_hours = duration_hours(dr.start_time, dr.end_time)
            if actual_hours is None:
                result.add_flag(
                    "FRACTIONAL_DAY_DURATION_MISMATCH",
                    f"Day {int(last_day_num)}: cannot read start/end time "
                    f"(expected {expected_hours:.1f}h for SF Site Time={sf_site_time})",
                )
                break
            if actual_hours != expected_hours:
                result.add_flag(
                    "FRACTIONAL_DAY_DURATION_MISMATCH",
                    f"Day {int(last_day_num)}: diary duration {actual_hours:.1f}h "
                    f"but expected {expected_hours:.1f}h "
                    f"(SF Site Time={sf_site_time}, {HOURS_PER_DAY}h/day)",
                )
            break


# ---------------------------------------------------------------------------
# Secondary consultant cross-check
# ---------------------------------------------------------------------------

def _check_secondary_consultants(result, sf_group, op_diary_rows, col_consultant, col_date):
    """
    Secondary consultant cross-check.

    Rules:
    - If SF has N consultants on a given date, there must be N diary rows for that date,
      each with a WITH <name> pointing at one of the other consultants on that date in SF.
    - For each diary WITH <name>: that name must appear in SF for that OP/date.
    - For each SF consultant on a date: there must be a diary row for them on that date.
    - If 3+ SF consultants on the same date: single flag asking for manual check.
    - A diary row with no corresponding SF entry is also flagged.
    """
    # Group SF rows by date
    sf_by_date: Dict[object, list] = {}  # date -> [cleaned consultant names]
    for _, sf_row in sf_group.iterrows():
        c = clean_consultant_name(sf_row[col_consultant]) if col_consultant else ""
        d = parse_deputy_date(sf_row[col_date]) if col_date else None
        if d is not None:
            if d not in sf_by_date:
                sf_by_date[d] = []
            if c:
                sf_by_date[d].append(c)

    # Group diary rows by date
    diary_by_date: Dict[object, list] = {}  # date -> [DiaryRow]
    for dr in op_diary_rows:
        if dr.start_date is not None:
            if dr.start_date not in diary_by_date:
                diary_by_date[dr.start_date] = []
            diary_by_date[dr.start_date].append(dr)

    # Check each date that has multiple SF consultants
    for date, sf_consultants in sf_by_date.items():
        n_sf = len(sf_consultants)
        if n_sf < 2:
            continue  # single consultant — not a WITH scenario

        diary_rows_on_date = diary_by_date.get(date, [])
        n_diary = len(diary_rows_on_date)

        # 3+ consultants: single manual-check flag, skip detailed validation
        if n_sf >= 3:
            result.add_flag(
                "MULTIPLE_CONSULTANTS_MANUAL_CHECK",
                f"{date}: {n_sf} consultants in SF — please check diary manually",
            )
            continue

        # Exactly 2 SF consultants on this date
        # Expect exactly 2 diary rows
        if n_diary != 2:
            result.add_flag(
                "SECONDARY_CONSULTANT_ROW_COUNT_MISMATCH",
                f"{date}: SF has 2 consultants but diary has {n_diary} row(s) "
                f"(expected 2, one per consultant each with WITH <other>)",
            )
            # Still check what we can
            if n_diary == 0:
                continue

        # For each diary row, verify WITH <name> points at someone in SF for this date
        for dr in diary_rows_on_date:
            if not dr.secondary_consultant:
                result.add_flag(
                    "SECONDARY_CONSULTANT_MISSING_WITH",
                    f"{date}: diary row for '{dr.employee_raw}' has no WITH notation "
                    f"(expected WITH <other consultant>)",
                )
                continue
            with_name = clean_consultant_name(dr.secondary_consultant)
            matched = any(compare_names(with_name, sf_c) for sf_c in sf_consultants)
            if not matched:
                result.add_flag(
                    "SECONDARY_CONSULTANT_NOT_IN_SF",
                    f"{date}: diary says 'WITH {with_name}' but that name is not in SF "
                    f"for this OP on this date (SF consultants: {', '.join(sf_consultants)})",
                )

        # For each SF consultant, verify they have a diary row on this date
        for sf_c in sf_consultants:
            has_diary_row = any(
                compare_names(sf_c, clean_consultant_name(dr.employee_raw))
                for dr in diary_rows_on_date
            )
            if not has_diary_row:
                result.add_flag(
                    "SECONDARY_CONSULTANT_DIARY_ROW_MISSING",
                    f"{date}: SF consultant '{sf_c}' has no diary row on this date",
                )

    # Check diary rows with WITH notation on dates that have only 1 SF consultant
    # (WITH on a single-consultant date is unexpected — flag it)
    for date, diary_rows in diary_by_date.items():
        sf_consultants = sf_by_date.get(date, [])
        if len(sf_consultants) >= 2:
            continue  # already handled above
        for dr in diary_rows:
            if dr.secondary_consultant:
                with_name = clean_consultant_name(dr.secondary_consultant)
                result.add_flag(
                    "SECONDARY_CONSULTANT_NOT_IN_SF",
                    f"{date}: diary says 'WITH {with_name}' but SF only shows 1 consultant on this date",
                )


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
# Site Time / Visit Entries match (informational, Option A)
# ---------------------------------------------------------------------------

def _compute_visit_entries_match(result, sf_group, col_map):
    """
    Compare ceil(SF Site Time) vs SF Visit Entries.
    Sets result.visit_entries_match to 'Match', 'No Match', or 'N/A'.
    """
    import math
    col_site_time     = col_map.get("site_time")
    col_visit_entries = col_map.get("visit_entries")

    if not col_site_time or not col_visit_entries:
        return  # leave as "N/A"

    sf_site_time = None
    sf_visit_entries = None

    for _, row in sf_group.iterrows():
        # Read Site Time
        if sf_site_time is None:
            val = row.get(col_site_time)
            try:
                if val is not None and not pd.isna(val):
                    sf_site_time = float(val)
            except (TypeError, ValueError):
                pass

        # Read Visit Entries
        if sf_visit_entries is None:
            val = row.get(col_visit_entries)
            try:
                if val is not None and not pd.isna(val):
                    sf_visit_entries = int(float(val))
            except (TypeError, ValueError):
                pass

        if sf_site_time is not None and sf_visit_entries is not None:
            break

    if sf_site_time is None or sf_visit_entries is None:
        return  # leave as "N/A"

    result.visit_entries_match = "Match" if math.ceil(sf_site_time) == sf_visit_entries else "No Match"


# ---------------------------------------------------------------------------

def run_validation(sf_df, diary_df, service_lookup):
    """
    Run full validation.
    Returns:
      results           — List[OpportunityResult] for SF OPs
      diary_op_not_in_sf — List of (op_number, diary_row) not found in SF
      unmapped_areas    — set of Deputy area strings not in config
      row_errors        — List[RowError]
    """
    diary_rows, row_errors = load_diary_rows(diary_df)

    # Identify SF columns
    col_op         = _find_column(sf_df, ["Opportunity Number", "OP Number", "OP No", "Opportunity No", "OP"])
    col_account    = _find_column(sf_df, ["Account Name", "Account", "Client", "Client Name"])
    col_service    = _find_column(sf_df, ["Service", "Service Name", "Product", "Product Name", "Service Type"])
    col_consultant = _find_column(sf_df, ["Consultant", "Consultant Name", "Engineer", "Staff", "Assigned To"])
    col_date       = _find_column(sf_df, ["Requested Visit Date/Time", "Requested Visit Date",
                                           "Visit Date", "Date", "Scheduled Date", "Appointment Date"])
    col_postcode   = _find_column(sf_df, ["Postcode", "Post Code", "Zip", "Postal Code"])
    col_site_time     = _find_column(sf_df, ["Site Time (Days)", "Site Time (days)", "site time (days)",
                                              "Site Time", "Site time", "site time", "SiteTime",
                                              "Site Days", "Days on Site", "Visit Days",
                                              "Days", "No of Days", "Number of Days"])
    col_visit_entries = _find_column(sf_df, ["Visit Entries", "Visit Entry", "Visit Count",
                                              "No of Visits", "Number of Visits"])

    col_map = {
        "op":            col_op,
        "account":       col_account,
        "service":       col_service,
        "consultant":    col_consultant,
        "date":          col_date,
        "postcode":      col_postcode,
        "site_time":     col_site_time,
        "visit_entries": col_visit_entries,
    }

    if not col_op:
        cols_found = list(sf_df.columns)
        raise ValueError(
            f"Could not find Opportunity Number column in SF data. "
            f"Columns found: {cols_found}"
        )

    # Surface detected column names for diagnostics (stored on the df as attrs)
    sf_df.attrs["_detected_cols"] = {k: v for k, v in col_map.items() if v}

    # Group SF by OP number — strip "OP-" prefix so "OP-12345" matches diary "12345"
    sf_df = sf_df.copy()
    sf_df["_op_clean"] = (
        sf_df[col_op].astype(str).str.strip()
        .str.replace(r"^OP-?\s*", "", regex=True)
        .str.strip()
    )

    # Build diary index: OP number -> list of DiaryRow
    diary_by_op: Dict[str, List[DiaryRow]] = {}
    for dr in diary_rows:
        for op_num in dr.op_candidates:
            if op_num not in diary_by_op:
                diary_by_op[op_num] = []
            diary_by_op[op_num].append(dr)

    # Track all diary OPs
    all_diary_ops = set(diary_by_op.keys())
    all_sf_ops = set(sf_df["_op_clean"].unique())

    results = []
    unmapped_areas = set()

    for op_number, group in sf_df.groupby("_op_clean"):
        op_diary_rows = diary_by_op.get(str(op_number), [])
        try:
            result = _process_opportunity(
                op_number=op_number,
                group=group,
                op_diary_rows=op_diary_rows,
                service_lookup=service_lookup,
                col_map=col_map,
            )
            # Site Time / Visit Entries match — Option A: ceil(Site Time) == Visit Entries
            _compute_visit_entries_match(result, group, col_map)
            results.append(result)
        except Exception as e:
            # Per-OP fault isolation
            err_result = OpportunityResult(
                opportunity_number=op_number,
                account_name="",
                sf_visits=len(group),
            )
            err_result.add_flag("PROCESSING_ERROR", str(e))
            results.append(err_result)

    # Collect unmapped areas from all diary rows
    for dr in diary_rows:
        for token in split_deputy_area(dr.area):
            if not token or service_lookup.is_admin_area(token):
                continue
            canonical = service_lookup.normalise_token(token)
            if canonical is None:
                unmapped_areas.add(token)

    # Diary OPs not in SF
    diary_op_not_in_sf = []
    for op_num in all_diary_ops - all_sf_ops:
        for dr in diary_by_op[op_num]:
            diary_op_not_in_sf.append((op_num, dr))

    return results, diary_op_not_in_sf, unmapped_areas, row_errors
