"""
Launcher for SF vs Deputy Validation Tool.
Starts the Streamlit server and opens the browser automatically.
"""
import sys
import os
import threading
import time
import webbrowser
import subprocess


def get_base_path():
    """Return the base path — works both in dev and as a PyInstaller bundle."""
    if getattr(sys, "frozen", False):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


def open_browser(port, delay=3):
    """Open the browser after a short delay to let Streamlit start."""
    time.sleep(delay)
    webbrowser.open(f"http://localhost:{port}")


def main():
    base_path = get_base_path()
    app_path = os.path.join(base_path, "app.py")

    port = 8501

    # Open browser in background thread
    t = threading.Thread(target=open_browser, args=(port,), daemon=True)
    t.start()

    # Run streamlit
    streamlit_cmd = [
        sys.executable if not getattr(sys, "frozen", False) else os.path.join(base_path, "_internal", "streamlit"),
        "-m", "streamlit", "run",
        app_path,
        "--server.port", str(port),
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false",
        "--server.fileWatcherType", "none",
    ]

    # When frozen, streamlit is a module inside the bundle
    if getattr(sys, "frozen", False):
        import streamlit.web.cli as stcli
        sys.argv = [
            "streamlit", "run",
            app_path,
            "--server.port", str(port),
            "--server.headless", "true",
            "--browser.gatherUsageStats", "false",
            "--server.fileWatcherType", "none",
        ]
        # Change working directory so relative CSV paths resolve
        os.chdir(base_path)
        sys.exit(stcli.main())
    else:
        os.chdir(base_path)
        subprocess.run([sys.executable, "-m", "streamlit", "run", app_path,
                        "--server.port", str(port),
                        "--server.headless", "true",
                        "--browser.gatherUsageStats", "false",
                        "--server.fileWatcherType", "none"])


if __name__ == "__main__":
    main()
