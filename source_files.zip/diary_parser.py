import re
import pandas as pd
from utils import parse_deputy_date, parse_deputy_time

# ---------------------------------------------------------------------------
# Regexes
# ---------------------------------------------------------------------------

# Exactly 5 digits with optional OP- prefix
_OP_SEGMENT_RE = re.compile(r"^(?:OP-?\s*)?(\d{5})$", re.IGNORECASE)

# Day X of Y (integers or decimals)
_DAY_OF_RE = re.compile(r"day\s*(\d+(?:\.\d+)?)\s*of\s*(\d+(?:\.\d+)?)", re.IGNORECASE)

# Full UK postcode — matches before and after space removal
# Pattern handles: SW1A 1AA, W1A 0AX, EC1A 1BB, etc.
# We search BEFORE stripping spaces so the regex can anchor properly.
_POSTCODE_RE = re.compile(
    r"\b([A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2})\b",
    re.IGNORECASE,
)

# Secondary consultant: WITH <name>
# Capture the name by consuming words one at a time.
# Stop before: digits, commas, parens, or known keywords (Day, OP, Report, SW, EC…).
_STOP_KEYWORDS = re.compile(
    r"^(?:day|op|report)\b"           # known diary keywords
    r"|^[A-Z]{1,2}\d",                # postcode-like token (e.g. SW1A, EC1, W1)
    re.IGNORECASE,
)

def _extract_with_name(note):
    """
    Extract the name following WITH in a diary note.
    Names are capitalised (Title Case). We require the first token to start
    with an uppercase letter, then consume further Title Case tokens up to 3 total.
    Stops at digits, punctuation, or a lowercase-starting word (common English word).
    """
    m = re.search(r"\bWITH\s+", note, re.IGNORECASE)
    if not m:
        return None
    remainder = note[m.end():]
    tokens = []
    for word in remainder.split():
        clean = word.strip(".,();:-")
        if not clean:
            # Standalone punctuation/hyphen — stop consuming (separator before client name)
            if tokens:
                break
            continue
        # Stop at digits or punctuation-only tokens
        if re.match(r"[\d\(\)]", clean[0]):
            break
        # Stop at stop keywords regardless of case
        if _STOP_KEYWORDS.match(clean):
            break
        # First token must start with uppercase (it's a name, not a sentence fragment)
        if not tokens and not clean[0].isupper():
            return None
        # Subsequent tokens: stop if starts with lowercase (common word like 'and', 'at')
        if tokens and clean[0].islower():
            break
        tokens.append(clean)
        if len(tokens) == 3:
            break
    return " ".join(tokens) if tokens else None

# Segments to protect when splitting on & — these contain literal & in the name
_PROTECT_PATTERNS = [
    ("H&S",           "__HS__"),
    ("Day & Night",   "__DAN__"),
    ("Night & Day",   "__NAD__"),
    ("C&D",           "__CD__"),
]


def _protect_ampersands(text):
    for phrase, placeholder in _PROTECT_PATTERNS:
        text = text.replace(phrase, placeholder)
    return text


def _restore_ampersands(text):
    for phrase, placeholder in _PROTECT_PATTERNS:
        text = text.replace(placeholder, phrase)
    return text


def _split_note_segments(note):
    """Split a diary note into leading segments (before any long text)."""
    # Split on common delimiters; take first few segments as candidates
    protected = _protect_ampersands(note)
    parts = re.split(r"[,/\|]", protected)
    restored = [_restore_ampersands(p).strip() for p in parts]
    return restored


def extract_op_candidates(note):
    """
    Extract 5-digit OP numbers from the leading segments of a diary note.
    Returns a list of strings (without OP- prefix).
    """
    if pd.isna(note):
        return []
    note_str = str(note)
    segments = _split_note_segments(note_str)
    results = []
    for seg in segments:
        # Each segment may contain multiple tokens
        tokens = seg.split()
        for token in tokens:
            m = _OP_SEGMENT_RE.match(token.strip())
            if m:
                results.append(m.group(1))
    return list(dict.fromkeys(results))  # deduplicate, preserve order


def extract_days_on_site(note):
    """
    Return (day_number, total_days) as floats, or (None, None).
    """
    if pd.isna(note):
        return None, None
    m = _DAY_OF_RE.search(str(note))
    if m:
        return float(m.group(1)), float(m.group(2))
    return None, None


def extract_postcode(note):
    """
    Extract UK postcode from a diary note.
    Searches the raw note (with spaces) for a full postcode.
    Returns normalised (no spaces, uppercase) or None.
    """
    if pd.isna(note):
        return None
    note_str = str(note).upper()
    m = _POSTCODE_RE.search(note_str)
    if m:
        # Normalise: remove internal spaces, uppercase
        return m.group(1).replace(" ", "").upper()
    return None


def extract_secondary_consultant(note):
    """
    Extract name from 'WITH <name>' in a diary note.
    Returns the name string or None.
    """
    if pd.isna(note):
        return None
    return _extract_with_name(str(note))


def parse_diary_note(note):
    """Return dict of parsed fields from a diary note."""
    op_candidates = extract_op_candidates(note)
    day_number, total_days = extract_days_on_site(note)
    postcode = extract_postcode(note)
    secondary_consultant = extract_secondary_consultant(note)
    return {
        "op_candidates": op_candidates,
        "day_number": day_number,
        "total_days": total_days,
        "postcode": postcode,
        "secondary_consultant": secondary_consultant,
        "is_multi_op": len(op_candidates) > 1,
    }


# ---------------------------------------------------------------------------
# Dataclass-style container
# ---------------------------------------------------------------------------

from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class DiaryRow:
    shift_id: str
    area: str
    employee_raw: str
    start_date: Optional[object]  # datetime.date
    start_time: Optional[object]  # datetime.time
    end_time: Optional[object]    # datetime.time
    note_raw: str
    op_candidates: List[str] = field(default_factory=list)
    day_number: Optional[float] = None
    total_days: Optional[float] = None
    postcode: Optional[str] = None
    secondary_consultant: Optional[str] = None
    is_multi_op: bool = False
