# -*- mode: python ; coding: utf-8 -*-
import os
import sys
from pathlib import Path
import streamlit

# Path to streamlit package (to bundle its static assets)
streamlit_dir = Path(streamlit.__file__).parent

block_cipher = None

a = Analysis(
    ['launcher.py'],
    pathex=['.'],
    binaries=[],
    datas=[
        # App source files
        ('app.py', '.'),
        ('matching_engine.py', '.'),
        ('service_lookup.py', '.'),
        ('diary_parser.py', '.'),
        ('utils.py', '.'),
        # Config CSVs — bundled alongside the app
        ('deputy_services_config.csv', '.'),
        ('sf_service_list_config.csv', '.'),
        ('oh_deputy_areas_config.csv', '.'),
        ('oh_sf_service_list_config.csv', '.'),
        # Streamlit static assets (web UI)
        (str(streamlit_dir / 'static'), 'streamlit/static'),
        (str(streamlit_dir / 'runtime'), 'streamlit/runtime'),
    ],
    hiddenimports=[
        'streamlit',
        'streamlit.web.cli',
        'streamlit.web.server',
        'streamlit.runtime',
        'streamlit.runtime.scriptrunner',
        'streamlit.runtime.caching',
        'streamlit.components.v1',
        'pandas',
        'pandas._libs.tslibs.np_datetime',
        'pandas._libs.tslibs.nattype',
        'pandas._libs.tslibs.timezones',
        'pandas._libs.skiplist',
        'openpyxl',
        'openpyxl.cell._writer',
        'rapidfuzz',
        'rapidfuzz.distance',
        'rapidfuzz.fuzz',
        'altair',
        'pyarrow',
        'click',
        'tornado',
        'packaging',
        'importlib_metadata',
        'tzdata',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['matplotlib', 'scipy', 'PIL', 'cv2', 'sklearn'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='SF Deputy Validation',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,   # No console window for end users
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='SF Deputy Validation',
)
