# SF vs Deputy Validation Tool

Validates Salesforce opportunity data against Deputy diary exports for H&S and OH divisions.

## For end users

Double-click **`SF Deputy Validation.exe`** — no installation needed.

The app opens in your browser automatically. Upload your SF and Deputy exports and click **Run Validation**.

---

## For developers / building the .exe

**Requirements:** Python 3.10+ installed on Windows.

1. Clone or download this repo
2. Double-click **`build.bat`**
3. The finished app appears in `dist\SF Deputy Validation\`
4. Zip and distribute that folder — users need nothing installed

---

## Files

| File | Purpose |
|------|---------|
| `app.py` | Streamlit UI |
| `matching_engine.py` | Core validation logic |
| `service_lookup.py` | Deputy area → SF service mapping |
| `diary_parser.py` | Diary note parsing (OP numbers, postcodes, WITH names) |
| `utils.py` | Date/time parsing, name comparison |
| `launcher.py` | Entry point — starts Streamlit and opens browser |
| `deputy_services_config.csv` | H&S Deputy area config |
| `sf_service_list_config.csv` | H&S SF service list |
| `oh_deputy_areas_config.csv` | OH Deputy area config |
| `oh_sf_service_list_config.csv` | OH SF service list |
| `SFDeputyValidation.spec` | PyInstaller build spec |
| `build.bat` | One-click Windows builder |
