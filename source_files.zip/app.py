"""
SF vs Deputy Diary Validation Tool
Streamlit web application.
"""
import io
import re
import streamlit as st
import pandas as pd

from service_lookup import ServiceLookup
from matching_engine import run_validation

st.set_page_config(page_title="SF vs Deputy Validation", layout="wide")

# ---------------------------------------------------------------------------
# Flag labels for display
# ---------------------------------------------------------------------------

FLAG_LABELS = {
    "MISSING_FROM_DIARY":                       "OP missing from diary",
    "SERVICE_MISMATCH":                         "Service mismatch",
    "DATE_MISMATCH":                            "Date mismatch",
    "POSTCODE_MISMATCH":                        "Postcode mismatch",
    "CONSULTANT_MISMATCH":                      "Consultant mismatch",
    "MULTIPLE_DIARY_ROWS_SAME_DATE":            "Multiple diary rows on same date",
    "SITE_TIME_MISMATCH":                       "Site time mismatch",
    "SITE_TIME_NEEDS_CONFIRMATION":             "Please confirm site time — not shown in diary",
    "FRACTIONAL_DAY_DURATION_MISMATCH":        "Fractional day duration mismatch",
    "MULTIPLE_CONSULTANTS_MANUAL_CHECK":        "2+ consultants on same date — please check manually",
    "SECONDARY_CONSULTANT_NOT_IN_SF":           "WITH consultant not found in SF",
    "SECONDARY_CONSULTANT_ROW_COUNT_MISMATCH":  "Wrong number of diary rows for multi-consultant visit",
    "SECONDARY_CONSULTANT_MISSING_WITH":        "Diary row missing WITH notation",
    "SECONDARY_CONSULTANT_DIARY_ROW_MISSING":   "SF consultant has no diary row on this date",
    "PROCESSING_ERROR":                         "Processing error",
}


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------

@st.cache_data
def load_reference_sheets(division):
    """Load the bundled config CSVs for the given division."""
    if division == "H&S":
        deputy_cfg = pd.read_csv("deputy_services_config.csv")
        sf_cfg     = pd.read_csv("sf_service_list_config.csv")
    else:  # OH
        deputy_cfg = pd.read_csv("oh_deputy_areas_config.csv")
        sf_cfg     = pd.read_csv("oh_sf_service_list_config.csv")
    return deputy_cfg, sf_cfg


def load_df(uploaded_file):
    """Load a single CSV or Excel file into a DataFrame."""
    if uploaded_file is None:
        return None
    name = uploaded_file.name.lower()
    if name.endswith(".csv"):
        return pd.read_csv(uploaded_file)
    elif name.endswith((".xlsx", ".xls")):
        return pd.read_excel(uploaded_file)
    else:
        st.error(f"Unsupported file format: {uploaded_file.name}")
        return None


def load_and_concat(uploaded_files):
    """Load and concatenate one or more uploaded files into a single DataFrame."""
    if not uploaded_files:
        return None
    dfs = []
    for f in uploaded_files:
        df = load_df(f)
        if df is not None:
            dfs.append(df)
    if not dfs:
        return None
    return pd.concat(dfs, ignore_index=True)


def _clean_text(df):
    """Replace curly/unicode dashes and quotes with plain ASCII equivalents."""
    str_cols = df.select_dtypes(include="object").columns
    replacements = {
        "–": "-",   # en dash
        "—": "-",   # em dash
        "‘": "'",   # left single quote
        "’": "'",   # right single quote
        "“": '"',   # left double quote
        "”": '"',   # right double quote
    }
    for col in str_cols:
        for bad, good in replacements.items():
            df[col] = df[col].astype(str).str.replace(bad, good, regex=False)
    return df


def to_excel_bytes(sheet_dict):
    """Write a dict of {sheet_name: DataFrame} to an Excel file in memory."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for sheet_name, df in sheet_dict.items():
            df = _clean_text(df.copy())
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Results building
# ---------------------------------------------------------------------------

def build_results_dataframe(results):
    rows = []
    for r in results:
        flags_text = "; ".join(
            FLAG_LABELS.get(f, f) for f in r.flags
        )
        details_text = "; ".join(
            f"{FLAG_LABELS.get(k, k)}: {v}"
            for k, v in r.flag_details.items()
        )
        rows.append({
            "Opportunity Number":           r.opportunity_number,
            "Account Name":                 r.account_name,
            "Diary Date(s)":               ", ".join(r.diary_dates) if r.diary_dates else "N/A",
            "Consultant(s)":               ", ".join(r.consultants) if r.consultants else "N/A",
            "Status":                       "FLAGGED" if r.flags else "OK",
            "Flags":                        flags_text if flags_text else "OK",
            "Flag Details":                 details_text if details_text else "",
            "Site Time/Visit Entries Match": r.visit_entries_match,
        })
    df = pd.DataFrame(rows)
    df = df.fillna("N/A")
    return df


def build_diary_not_in_sf_dataframe(diary_op_not_in_sf):
    rows = []
    for op_num, dr in diary_op_not_in_sf:
        rows.append({
            "OP Number":  op_num,
            "Employee":   dr.employee_raw,
            "Date":       str(dr.start_date) if dr.start_date else "N/A",
            "Area":       dr.area,
            "Note":       dr.note_raw[:200],
        })
    df = pd.DataFrame(rows)
    df = df.fillna("N/A")
    return df


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

st.title("SF vs Deputy Diary Validation")
st.markdown("Upload your Salesforce export and Deputy diary export to check for mismatches.")

# Division selector
division = st.radio(
    "Division",
    options=["H&S", "OH"],
    horizontal=True,
    help="Select the division to use the correct service configuration.",
)

st.divider()

col1, col2 = st.columns(2)
with col1:
    sf_files = st.file_uploader(
        "Salesforce Export (CSV or Excel) — multiple files allowed",
        type=["csv", "xlsx", "xls"],
        key="sf_file",
        accept_multiple_files=True,
    )
with col2:
    diary_files = st.file_uploader(
        "Deputy Diary Export (CSV or Excel) — multiple files allowed",
        type=["csv", "xlsx", "xls"],
        key="diary_file",
        accept_multiple_files=True,
    )

run_button = st.button("▶ Run Validation", type="primary", disabled=(not sf_files or not diary_files))

if run_button:
    with st.spinner("Loading files..."):
        sf_df    = load_and_concat(sf_files)
        diary_df = load_and_concat(diary_files)

    if sf_df is None or diary_df is None:
        st.error("Could not load one or both files.")
        st.stop()

    with st.spinner("Loading configuration..."):
        try:
            deputy_cfg, sf_cfg = load_reference_sheets(division)
            service_lookup = ServiceLookup(division, deputy_cfg, sf_cfg)
        except Exception as e:
            st.error(f"Failed to load configuration: {e}")
            st.stop()

    with st.spinner("Running validation..."):
        try:
            results, diary_not_in_sf, unmapped_areas, row_errors = run_validation(
                sf_df, diary_df, service_lookup
            )
        except Exception as e:
            st.error(f"Validation failed: {e}")
            st.stop()

    # Build DataFrames
    results_df         = build_results_dataframe(results)
    diary_not_in_sf_df = build_diary_not_in_sf_dataframe(diary_not_in_sf)
    flagged_df         = results_df[results_df["Status"] == "FLAGGED"]
    all_results_df     = results_df.drop(columns=["Site Time/Visit Entries Match"])

    # Show detected SF columns in an expander for diagnostics
    detected = sf_df.attrs.get("_detected_cols", {})
    with st.expander("Column detection (click to verify)", expanded=False):
        col_rows = [{"Field": k, "Detected column": v} for k, v in detected.items()]
        if not detected.get("site_time"):
            col_rows.append({"Field": "site_time", "Detected column": "NOT FOUND — check column name"})
        st.dataframe(pd.DataFrame(col_rows), use_container_width=True)
        st.caption("If 'site_time' shows NOT FOUND, the Site Time column in your SF export has a different name. "
                   "Rename it to 'Site Time' and re-upload.")

    # Summary metrics
    total_ops       = len(results)
    flagged_ops     = len(flagged_df)
    diary_not_in_sf_count = len(set(op for op, _ in diary_not_in_sf))
    unmapped_count  = len(unmapped_areas)
    error_count     = len(row_errors)

    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Total SF OPs",         total_ops)
    m2.metric("Flagged",               flagged_ops)
    m3.metric("Diary OPs not in SF",   diary_not_in_sf_count)
    m4.metric("Unmapped areas",        unmapped_count)
    m5.metric("Row errors",            error_count)

    st.divider()

    # Build unmapped and error DataFrames for export
    unmapped_df = pd.DataFrame(sorted(unmapped_areas), columns=["Deputy Area"]) if unmapped_areas else pd.DataFrame(columns=["Deputy Area"])
    err_df = pd.DataFrame([
        {"Row": e.row_index, "Error": e.error_message, "Raw Data": e.raw_data[:200]}
        for e in row_errors
    ]) if row_errors else pd.DataFrame(columns=["Row", "Error", "Raw Data"])

    # Single Excel export — one sheet per tab
    excel_bytes = to_excel_bytes({
        "Flagged Opportunities": flagged_df,          # includes Site Time/Visit Entries Match
        "Diary OPs Not In SF":   diary_not_in_sf_df,
        "Unmapped Areas":        unmapped_df,
        "Row Errors":            err_df,
        "All Results":           all_results_df,      # excludes Site Time/Visit Entries Match
    })
    st.download_button(
        "⬇️ Download Full Report (Excel)",
        data=excel_bytes,
        file_name="validation_report.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )

    st.divider()

    # Tabs
    tabs = st.tabs([
        "Flagged Opportunities",
        "Diary OPs Not In SF",
        "Unmapped Deputy Areas",
        "Row Errors",
        "All Results",
    ])

    with tabs[0]:
        st.subheader(f"Flagged Opportunities ({flagged_ops})")
        if flagged_df.empty:
            st.success("No flagged opportunities — all checks passed!")
        else:
            st.dataframe(flagged_df, use_container_width=True)

    with tabs[1]:
        st.subheader(f"Diary OPs Not In SF ({diary_not_in_sf_count} unique OPs)")
        if diary_not_in_sf_df.empty:
            st.success("All diary OPs found in SF.")
        else:
            st.dataframe(diary_not_in_sf_df, use_container_width=True)

    with tabs[2]:
        st.subheader(f"Unmapped Deputy Areas ({unmapped_count})")
        if not unmapped_areas:
            st.success("All Deputy areas mapped successfully.")
        else:
            st.write("These Deputy area names were not found in the service config:")
            st.dataframe(unmapped_df, use_container_width=True)

    with tabs[3]:
        st.subheader(f"Row Errors ({error_count})")
        if not row_errors:
            st.success("No row errors.")
        else:
            st.dataframe(err_df, use_container_width=True)

    with tabs[4]:
        st.subheader(f"All Results ({total_ops} OPs)")
        st.dataframe(all_results_df, use_container_width=True)
