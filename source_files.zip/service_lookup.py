"""
Division-aware service lookup.
Handles H&S and OH divisions with separate config schemas.
"""
import re
import pandas as pd

# ---------------------------------------------------------------------------
# H&S constants
# ---------------------------------------------------------------------------

# Maps Deputy area tokens (lowercased) to SF service names
# These handle abbreviations / alternative names used in Deputy
EXTRA_TOKEN_MAPPINGS_HS = {
    "h&s audit":                        "Health & Safety Risk Assessment",
    "h&s risk assessment":              "Health & Safety Risk Assessment",
    "fire risk assessment":             "Fire Risk Assessment",
    "fra":                              "Fire Risk Assessment",
    "fra t1":                           "Fire Risk Assessment Tier 1",
    "fra t2":                           "Fire Risk Assessment Tier 2",
    "fra t3":                           "Fire Risk Assessment Tier 3",
    "fra t2 & gra":                     "Fire Risk Assessment Tier 2",  # GRA handled separately
    "fire evacuation plan":             "Fire Evacuation Plan",
    "fra & fire evacuation plan":       "Fire Risk Assessment",         # compound — split handled below
    "fra & fire evacuation":            "Fire Risk Assessment",
    "dsear desktop study/review":       "DSEAR Desktop Study",
    "dsear desktop study":              "DSEAR Desktop Study",
    "dsear ra":                         "DSEAR Risk Assessment",
    "gap analysis/site assessment":     "Health & Safety Gap Analysis",
    "h&s gap analysis":                 "Health & Safety Gap Analysis",
    "hac drawings":                     "Hazardous Area Classification Drawings (HAC)",
    "hazardous area classification drawings (hac)": "Hazardous Area Classification Drawings (HAC)",
    "hac":                              "Hazardous Area Classification Drawings (HAC)",
    "h&s consultancy":                  "H&S General Consultancy",
    "puwer assessment":                 "PUWER Assessment",
    "compartmentation survey":          "Compartmentation Survey",
}

# Extra token mappings for OH division
EXTRA_TOKEN_MAPPINGS_OH = {
    "noise mapping":                    "Noise Mapping",
    "noise & noise map":                "Noise Monitoring",   # compound — "Noise Mapping" added separately
    "noise & noise mapping":            "Noise Monitoring",
    "bioaerosol monitoring":            "Bioaerosol Monitoring",
    "bioaerosol moni":                  "Bioaerosol Monitoring",
    "lev smoke clearance test":         "LEV Smoke Clearance Test",
    "smoke clearence":                  "LEV Smoke Clearance Test",   # typo variant
    "whole body vibration":             "Whole Body Vibration",
    "wbv":                              "Whole Body Vibration",
    "biological monitoring":            "Biological Monitoring",
    "biological":                       "Biological Monitoring",
    "env. noise - day & night":         "Environmental Noise Monitoring",
    "env. noise - day":                 "Environmental Noise Monitoring",  # post-split fragment
    "night":                            "Environmental Noise Monitoring",  # post-split fragment (env noise)
    "light level - day & night":        "Lighting",
    "light level - day":                "Lighting",           # post-split fragment
    "fra & fire evacuation":            "Fire Risk Assessment",
    # Compound phrases protected from splitting — looked up as single restored tokens
    "wam & bioaerosol monitoring":      "Workplace Air Monitoring",
    "iaq & bioaerosol monitoring":      "IAQ",
    "noise & noise map":                "Noise Monitoring",
    "noise & noise mapping":            "Noise Monitoring",
    "fra t2 & gra":                     "Fire Risk Assessment Tier 2",
    "fra & fire evacuation plan":       "Fire Risk Assessment",
    "fra & fire evacuation":            "Fire Risk Assessment",
}

# Pairs of SF service names that are interchangeable
INTERCHANGEABLE_SF_SERVICES_HS = [
    {"Fire Door Survey", "Fire Door Inspection"},
    {"DSEAR Desktop Study", "DSEAR Desktop Study/Review"},
]

# FRA tier hierarchy — only the highest tier sold needs diary entry
FRA_TIER_HIERARCHY = ["Fire Risk Assessment Tier 1",
                       "Fire Risk Assessment Tier 2",
                       "Fire Risk Assessment Tier 3"]

# Deputy areas that represent admin/report time — skipped for service matching
ADMIN_AREAS = {
    "report time",
    "checking",
    "do not move office/reports",
    "leave",
    "non-working day",
    "office / reports",
    "tech lead / report checks",
    "training / course",
    "travel",
    "travel/reports",
}

# ---------------------------------------------------------------------------
# Ampersand protection for splitting
# ---------------------------------------------------------------------------

_PROTECT = [
    ("H&S",                    "__HS__"),
    ("Day & Night",            "__DAN__"),
    ("Night & Day",            "__NAD__"),
    ("C&D",                    "__CD__"),
    ("Env. Noise - Day & Night",  "__ENDAYNIGHT__"),
    ("Light Level - DAY & NIGHT", "__LLDAYNIGHT__"),
    ("FRA T2 & GRA",           "__FRAT2GRA__"),
    ("FRA & Fire Evacuation Plan", "__FRAEVACPLAN__"),
    ("FRA & Fire Evacuation",  "__FRAEVAC__"),
    ("WAM & Bioaerosol Monitoring", "__WAMBIO__"),
    ("IAQ & Bioaerosol Monitoring", "__IAQBIO__"),
    ("Noise & Noise Map",      "__NOISENOISEMAP__"),
    ("Noise & Noise Mapping",  "__NOISEMAP__"),
]


def _protect(text):
    for phrase, ph in _PROTECT:
        text = text.replace(phrase, ph)
    return text


def _restore(text):
    for phrase, ph in _PROTECT:
        text = text.replace(ph, phrase)
    return text


def split_deputy_area(area_str):
    """Split a Deputy area string on commas and '&', protecting known compound names."""
    if pd.isna(area_str):
        return []
    protected = _protect(str(area_str))
    parts = re.split(r"[,&]", protected)
    return [_restore(p).strip() for p in parts if _restore(p).strip()]


# ---------------------------------------------------------------------------
# ServiceLookup class
# ---------------------------------------------------------------------------

class ServiceLookup:
    """
    Loads service config CSVs and provides lookup methods.

    H&S CSVs:
      deputy_config_df  — columns: Deputy Area, SF Service (or Abbreviation)
      sf_config_df      — columns: SF Service, Abbreviation

    OH CSVs:
      deputy_config_df  — columns: Deputy Area, Canonical Name, Work Type
      sf_config_df      — columns: SF Service, Abbreviation
    """

    def __init__(self, division, deputy_config_df, sf_config_df):
        self.division = division.upper()
        self._build_hs_lookup(deputy_config_df, sf_config_df) if self.division == "H&S" else \
            self._build_oh_lookup(deputy_config_df, sf_config_df)

    # ------------------------------------------------------------------
    # H&S build
    # ------------------------------------------------------------------

    def _build_hs_lookup(self, deputy_df, sf_df):
        # deputy area -> SF service name
        self._deputy_to_sf = {}
        for _, row in deputy_df.iterrows():
            area = str(row.iloc[0]).strip()
            sf_service = str(row.iloc[1]).strip() if len(row) > 1 else ""
            if area and sf_service and sf_service.lower() not in ("nan", ""):
                self._deputy_to_sf[area.lower()] = sf_service

        # SF service -> list of deputy abbreviations/tokens
        self._sf_to_deputy_tokens = {}
        for _, row in sf_df.iterrows():
            sf_service = str(row.iloc[0]).strip()
            abbrev = str(row.iloc[1]).strip() if len(row) > 1 else ""
            if sf_service and sf_service.lower() not in ("nan", ""):
                tokens = [sf_service.lower()]
                if abbrev and abbrev.lower() not in ("nan", ""):
                    tokens.append(abbrev.lower())
                self._sf_to_deputy_tokens[sf_service] = tokens

        # Add extra mappings
        for token, sf_name in EXTRA_TOKEN_MAPPINGS_HS.items():
            self._deputy_to_sf[token.lower()] = sf_name

        self._interchangeable = INTERCHANGEABLE_SF_SERVICES_HS
        self._admin_areas = {a.lower() for a in ADMIN_AREAS}

    # ------------------------------------------------------------------
    # OH build
    # ------------------------------------------------------------------

    def _build_oh_lookup(self, deputy_df, sf_df):
        # Deputy Area -> Canonical Name (None if blank = use raw token)
        self._oh_area_to_canonical = {}
        for _, row in deputy_df.iterrows():
            deputy_area = str(row.iloc[0]).strip()
            canonical = str(row.iloc[1]).strip() if len(row) > 1 else ""
            if canonical.lower() in ("nan", ""):
                canonical = None
            if deputy_area:
                self._oh_area_to_canonical[deputy_area.lower()] = canonical

        # SF service -> abbreviation tokens
        self._sf_to_deputy_tokens = {}
        for _, row in sf_df.iterrows():
            sf_service = str(row.iloc[0]).strip()
            abbrev = str(row.iloc[1]).strip() if len(row) > 1 else ""
            if sf_service and sf_service.lower() not in ("nan", ""):
                tokens = [sf_service.lower()]
                if abbrev and abbrev.lower() not in ("nan", ""):
                    tokens.append(abbrev.lower())
                self._sf_to_deputy_tokens[sf_service] = tokens

        # Add extra OH mappings (abbreviations, compounds, variants)
        for token, sf_name in EXTRA_TOKEN_MAPPINGS_OH.items():
            self._oh_area_to_canonical[token.lower()] = sf_name

        self._interchangeable = []
        self._admin_areas = {a.lower() for a in ADMIN_AREAS}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_admin_area(self, area_token):
        return area_token.strip().lower() in self._admin_areas

    def deputy_area_to_sf_service(self, area_token):
        """Map a single Deputy area token to an SF service name, or None."""
        key = area_token.strip().lower()
        if self.division == "H&S":
            return self._deputy_to_sf.get(key)
        else:
            # OH: look up canonical, use canonical as SF service name
            canonical = self._oh_area_to_canonical.get(key)
            if canonical is None:
                # Return raw token itself (e.g. IAQ, EMF)
                return area_token.strip()
            return canonical

    def sf_service_to_deputy_tokens(self, sf_service):
        """Return list of deputy-side tokens for an SF service name."""
        return self._sf_to_deputy_tokens.get(sf_service, [sf_service.lower()])

    def services_are_equivalent(self, sf_service_a, sf_service_b):
        """Check if two SF service names are interchangeable."""
        for pair in self._interchangeable:
            if sf_service_a in pair and sf_service_b in pair:
                return True
        return False

    def is_fra_tier(self, service_name):
        return service_name in FRA_TIER_HIERARCHY

    def reduce_fra_tiers(self, services):
        """
        Given a list of SF services, reduce FRA tiers to just the highest.
        E.g. [T1, T2, T3, other] -> [T3, other]
        """
        tiers_present = [s for s in services if s in FRA_TIER_HIERARCHY]
        non_tiers = [s for s in services if s not in FRA_TIER_HIERARCHY]
        if not tiers_present:
            return services
        highest = max(tiers_present, key=lambda t: FRA_TIER_HIERARCHY.index(t))
        return non_tiers + [highest]

    def get_all_deputy_areas(self):
        """Return all known Deputy area strings (lowercased keys)."""
        if self.division == "H&S":
            return set(self._deputy_to_sf.keys())
        else:
            return set(self._oh_area_to_canonical.keys())

    def normalise_token(self, token):
        """
        Normalise a Deputy area token to the canonical SF-facing name.
        Returns None if this is an admin area.
        """
        if self.is_admin_area(token):
            return None
        result = self.deputy_area_to_sf_service(token)
        return result
